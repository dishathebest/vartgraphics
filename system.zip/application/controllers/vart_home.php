<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Vart_home extends CI_Controller {

    function __construct() {
	parent::__construct();
	$this->load->model(array('category_model','banner_model'));
    }

    public function index() {
	$data['content'] = "vart_home";
	$data['title'] = "V.Art Graphics";
	$data['introduction'] = $this->cms->getPageById(5);
	$data['passion'] = $this->cms->getPageById(6);
	$data['categoryList']=$this->category_model->getParentCategoryList(array("cat_id","cat_name","cat_description","image_home"));
	$data['bannerList']=$this->banner_model->getBannerList(array("banner_id","image"));
	$this->load->view('main_template', $data);
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */