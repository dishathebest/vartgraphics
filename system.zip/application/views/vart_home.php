<div id="home">
<!-- Slider Starts -->
<div id="myCarousel" class="carousel slide banner-slider animated bounceInDown" data-ride="carousel">     
      <div class="carousel-inner">
      <?php $i=1;foreach($bannerList as $banner){?>
      <div class="item <?= $i==1?"active":"" ?>">
          <img src="<?= base_url() ?>images/home_banner/<?= $banner->image ?>" alt="banner">
        </div>
	  <?php $i++;}?>
        <!-- Item 1 
        <div class="item">
          <img src="<?= base_url() ?>images/back1.jpg" alt="banner">
        </div>
        <!-- #Item 1 -->

        <!-- Item 1 
        <div class="item">
          <img src="<?= base_url() ?>images/back2.jpg" alt="banner">
        </div>
        <!-- #Item 1 

        <!-- Item 1 
        <div class="item">
          <img src="<?= base_url() ?>images/back3.jpg" alt="banner">
        </div>
        <!-- #Item 1 

        <!-- Item 1 
        <div class="item">
          <img src="<?= base_url() ?>images/back4.jpg" alt="banner">
        </div>
        <!-- #Item 1 -->
      </div>
      <a class="left carousel-control" href="#myCarousel" data-slide="prev"><span class="glyphicon-chevron-left"><i class="fa fa-angle-left"></i></span></a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next"><span class="glyphicon-chevron-right"><i class="fa fa-angle-right"></i></span></a>
    </div>
<!-- #Slider Ends -->
</div>

<!-- Cirlce Starts -->
<div id="about" class="container spacer about">
<h2 style="visibility: visible; animation-name: fadeInUp;" class="text-center wowload fadeInUp animated">Creative Graphic Designers</h2>  
  <div class="row">
  <div style="visibility: visible; animation-name: fadeInLeft;" class="col-sm-6 wowload fadeInLeft animated">
    <h4><i class="fa fa-camera-retro"></i> <?= $introduction->page_title ?></h4>
    <?= $introduction->content ?>
    

  </div>
  <div style="visibility: visible; animation-name: fadeInRight;" class="col-sm-6 wowload fadeInRight animated">
  <h4><i class="fa fa-coffee"></i> <?= $passion->page_title ?></h4>
  <?= $passion->content ?>
  </div>
  </div>

  <div class="services">
  <h3 style="visibility: visible; animation-name: fadeInUp;" class="text-center wowload fadeInUp animated">Services</h3>
	<ul style="visibility: visible; animation-name: bounceInUp;" class="row text-center list-inline  wowload bounceInUp animated">
   		<li>
            <span><i class="fa fa-camera-retro"></i><b>Photography</b></span>
        </li>
        <li>
            <span><i class="fa fa-cube"></i><b>Studio</b></span>
        </li>
        <li>
            <span><i class="fa fa-graduation-cap"></i><b>Trainings</b></span>
        </li>
        <li>
            <span><i class="fa fa-umbrella"></i><b>Travel</b></span>
        </li>        
        <li>
            <span><i class="fa fa-heart-o"></i><b>Wedding</b></span>
        </li>
  	</ul>
  </div>
</div>
<!-- #Cirlce Ends -->


<!-- works -->
<div id="works" class=" clearfix grid">
	<?php foreach($categoryList as $cat){ ?>
    <figure style="visibility: visible; animation-name: fadeInUp;" class="effect-oscar  wowload fadeInUp animated">
        <img src="<?= base_url() ?>images/home_category/<?= $cat->image_home ?>" alt="img01">
        <figcaption>
            <h2><?= $cat->cat_name ?></h2>
            <p><?= $cat->cat_description ?><br>
            <a href="http://thebootstrapthemes.com/live/thebootstrapthemes-photography/images/portfolio/1.jpg" title="1" data-gallery="">View more</a></p>            
        </figcaption>
    </figure>
	<?php } ?>
   </div>
<!-- works -->


<div id="partners" class="container spacer ">
	<h2 style="visibility: visible; animation-name: fadeInUp;" class="text-center  wowload fadeInUp animated">Some of our happy clients</h2>
  <div class="clearfix">
    <div style="visibility: visible; animation-name: fadeInLeft;" class="col-sm-6 partners  wowload fadeInLeft animated">
         <img src="<?= base_url() ?>images/1.jpg" alt="partners">
         <img src="<?= base_url() ?>images/2_002.jpg" alt="partners">
         <img src="<?= base_url() ?>images/3.jpg" alt="partners">
         <img src="<?= base_url() ?>images/4.jpg" alt="partners">
    </div>
    <div class="col-sm-6">


    <div style="visibility: visible; animation-name: fadeInRight;" id="carousel-testimonials" class="carousel slide testimonails  wowload fadeInRight animated" data-ride="carousel">
    <div class="carousel-inner">  
      <div class="item animated bounceInRight row">
      <div class="animated slideInLeft col-xs-2"><img alt="portfolio" src="<?= base_url() ?>images/1_002.jpg" class="img-circle img-responsive" width="100"></div>
      <div class="col-xs-10">
      <p> I must explain to you how all this mistaken idea of denouncing
 pleasure and praising pain was born and I will give you a complete 
account of the system, and expound the actual teachings of the great 
explorer of the truth, the master-builder of human happiness. </p>      
      <span>Angel Smith - <b>eshop Canada</b></span>
      </div>
      </div>
      <div class="item  animated bounceInRight row">
      <div class="animated slideInLeft col-xs-2"><img alt="portfolio" src="<?= base_url() ?>images/2_003.jpg" class="img-circle img-responsive" width="100"></div>
      <div class="col-xs-10">
      <p>No one rejects, dislikes, or avoids pleasure itself, because it
 is pleasure, but because those who do not know how to pursue pleasure 
rationally encounter consequences that are extremely painful.</p>
      <span>John Partic - <b>Crazy Pixel</b></span>
      </div>
      </div>
      <div class="item  animated bounceInRight row active">
      <div class="animated slideInLeft  col-xs-2"><img alt="portfolio" src="<?= base_url() ?>images/3_002.jpg" class="img-circle img-responsive" width="100"></div>
      <div class="col-xs-10">
      <p>On the other hand, we denounce with righteous indignation and 
dislike men who are so beguiled and demoralized by the charms of 
pleasure of the moment, so blinded by desire, that they cannot foresee 
the pain and trouble that are bound to ensue.</p>
      <span>Harris David - <b>Jet London</b></span>
      </div>
      </div>
  </div>

   <!-- Indicators -->
   	<ol class="carousel-indicators">
    <li data-target="#carousel-testimonials" data-slide-to="0" class=""></li>
    <li class="" data-target="#carousel-testimonials" data-slide-to="1"></li>
    <li class="active" data-target="#carousel-testimonials" data-slide-to="2"></li>
  	</ol>
  	<!-- Indicators -->
  </div>



    </div>
  </div>


<!-- team -->
<h3 style="visibility: visible; animation-name: fadeInUp;" class="text-center  wowload fadeInUp animated">Our team</h3>
<p style="visibility: visible; animation-name: fadeInLeft;" class="text-center  wowload fadeInLeft animated">Our creative team that is making everything possible</p>
<div style="visibility: visible; animation-name: fadeInUpBig;" class="row grid team  wowload fadeInUpBig animated">	
	<div class=" col-sm-3 col-xs-6">
	<figure class="effect-chico">
        <img src="<?= base_url() ?>images/8_002.jpg" alt="img01" class="img-responsive">
        <figcaption>
            <p><b>Barbara Husto</b><br>Senior Designer<br><br><a href="#"><i class="fa fa-dribbble"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-twitter"></i></a></p>            
        </figcaption>
    </figure>
    </div>

    <div class=" col-sm-3 col-xs-6">
	<figure class="effect-chico">
        <img src="<?= base_url() ?>images/10.jpg" alt="img01">
        <figcaption>            
            <p><b>Barbara Husto</b><br>Senior Designer<br><br><a href="#"><i class="fa fa-dribbble"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-twitter"></i></a></p>            
        </figcaption>
    </figure>
    </div>

    <div class=" col-sm-3 col-xs-6">
	<figure class="effect-chico">
        <img src="<?= base_url() ?>images/12.jpg" alt="img01">
        <figcaption>
            <p><b>Barbara Husto</b><br>Senior Designer<br><br><a href="#"><i class="fa fa-dribbble"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-twitter"></i></a></p>          
        </figcaption>
    </figure>
    </div>

    <div class=" col-sm-3 col-xs-6">
	<figure class="effect-chico">
        <img src="<?= base_url() ?>images/17.jpg" alt="img01">
        <figcaption>
            <p><b>Barbara Husto</b><br>Senior Designer<br><br><a href="#"><i class="fa fa-dribbble"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-twitter"></i></a></p>
        </figcaption>
    </figure>
    </div>

 
</div>
<!-- team -->

</div>









<!-- About Starts -->
<div class="highlight-info">
<div class="overlay spacer">
<div class="container">
<div style="visibility: visible; animation-name: fadeInDownBig;" class="row text-center  wowload fadeInDownBig animated">
	<div class="col-sm-3 col-xs-6">
	<i class="fa fa-smile-o  fa-5x"></i><h4>24 Clients</h4>
	</div>
	<div class="col-sm-3 col-xs-6">
	<i class="fa fa-rocket  fa-5x"></i><h4>75 Projects</h4>
	</div>
	<div class="col-sm-3 col-xs-6">
	<i class="fa fa-cloud-download  fa-5x"></i><h4>454 Downloads</h4>
	</div>
	<div class="col-sm-3 col-xs-6">
	<i class="fa fa-map-marker fa-5x"></i><h4>2 Offices</h4>
	</div>
</div>
</div>
</div>
</div>
<!-- About Ends -->








<div id="contact" class="spacer">
<!--Contact Starts-->
<div class="container contactform center">
<h2 style="visibility: visible; animation-name: fadeInUp;" class="text-center  wowload fadeInUp animated">Get in touch to start your project</h2>
  <div style="visibility: visible; animation-name: fadeInLeftBig;" class="row wowload fadeInLeftBig animated">      
      <div class="col-sm-6 col-sm-offset-3 col-xs-12">      
        <input placeholder="Name" type="text">
        <input placeholder="Company" type="text">
        <textarea rows="5" placeholder="Message"></textarea>
        <button class="btn btn-primary"><i class="fa fa-paper-plane"></i> Send</button>
      </div>
  </div>



</div>
</div>
<!--Contact Ends-->