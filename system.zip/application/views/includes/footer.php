<!-- Footer Starts -->
<div class="footer text-center spacer">
<p style="visibility: visible; animation-name: flipInX;" class="wowload flipInX animated"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-instagram fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-flickr fa-2x"></i></a> </p>
Powered by: <a href="http://thebootstrapthemes.com/live/thebootstrapthemes-photography/thebootstrapthemes.com">thebootstrapthemes.com</a>
</div>
<!-- # Footer Ends -->
<a href="#home" class="gototop "><i class="fa fa-angle-up  fa-3x"></i></a>





<!-- The Bootstrap Image Gallery lightbox, should be a child element of the document body -->
<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls">
    <!-- The container for the modal slides -->
    <div class="slides"></div>
    <!-- Controls for the borderless lightbox -->
    <h3 class="title">Title</h3>
    <a class="prev">‹</a>
    <a class="next">›</a>
    <a class="close">×</a>
    <!-- The modal dialog, which will be used to wrap the lightbox content -->    
</div>



<!-- jquery -->
<script src="<?= base_url() ?>js/jquery.min.js"></script>

<!-- wow script -->
<script src="<?= base_url() ?>js/wow.js"></script>

<!-- boostrap -->
<script src="<?= base_url() ?>js/bootstrap.min.js" type="text/javascript"></script>

<!-- jquery mobile -->
<script src="<?= base_url() ?>js/touchSwipe.js"></script>
<script src="<?= base_url() ?>js/respond.js"></script>

<!-- gallery -->
<script src="<?= base_url() ?>js/jquery.js"></script>

<!-- custom script -->
<script src="<?= base_url() ?>js/script.js"></script>


</body></html>